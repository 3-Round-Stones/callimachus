/*
 * Copyright (c) 2013 3 Round Stones Inc., Some Rights Reserved
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */
package org.callimachusproject.client;

import java.io.Closeable;
import java.io.IOException;

import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.HttpRequest;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.cache.ManagedHttpCacheStorage;
import org.apache.http.params.HttpParams;
import org.apache.http.protocol.HttpContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * This class allows an HttpClient to be shared among managers that each think
 * it is just for them. By ignoring calls to {@link CloseableHttpClient#close()}
 * and waiting for object finalisation this allows this object to shared.
 * 
 * @author James Leigh
 * 
 */
public class AutoClosingHttpClient extends CloseableHttpClient {
	final Logger logger = LoggerFactory.getLogger(AutoClosingHttpClient.class);
	private final CloseableHttpClient client;
	private final ManagedHttpCacheStorage storage;
	private int numberOfClientCalls = 0;

	public AutoClosingHttpClient(CloseableHttpClient client, ManagedHttpCacheStorage storage) {
		this.client = client;
		this.storage = storage;
	}

	@Override
	protected void finalize() throws Throwable {
		client.close();
		storage.shutdown();
	}

	public void cleanResources() {
		storage.cleanResources();
	}

    public void close() throws IOException {
		// ignore close request and wait for finalisation
		storage.cleanResources();
    }

	@Override
	protected CloseableHttpResponse doExecute(final HttpHost host, final HttpRequest request,
            HttpContext ctx) throws IOException, ClientProtocolException {
		if (++numberOfClientCalls % 100 == 0) {
			// Deletes the (no longer used) temporary cache files from disk.
			cleanResources();
		}
		CloseableHttpResponse resp = client.execute(host, request, ctx);
		HttpEntity entity = resp.getEntity();
		if (entity != null) {
			resp.setEntity(new CloseableEntity(entity, new Closeable() {
				public void close() throws IOException {
					// this also keeps this object from being finalized
					// until all its response entities are consumed
					String uri = request.getRequestLine().getUri();
					logger.debug("Remote {}{} closed", host, uri);
				}
			}));
		}
		return resp;
	}

	@Override
	public ClientConnectionManager getConnectionManager() {
		return client.getConnectionManager();
	}

	@Override
	public HttpParams getParams() {
		return client.getParams();
	}

}
